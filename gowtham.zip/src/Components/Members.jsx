import React from 'react'
import { Container, Row,Col } from 'react-bootstrap'
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import Card from 'react-bootstrap/Card';
import img9 from "../images/advsr1.png";
import img10 from "../images/advsr2.png";
import img11 from "../images/advsr3.png";
import img12 from "../images/advsr4.png";
import img13 from "../images/advsr5.png";
import img14 from "../images/advsr6.png";

function Members () {
    const responsive = {
        superLargeDesktop: {
          // the naming can be any, depends on you.
          breakpoint: { max: 4000, min: 3000 },
          items: 6
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 5
          },
      };

  return (



    <Container style={{marginTop:'5rem'}}>
        <Row >
            <Col >
           <h4  className='c3t1'>Advisory Members</h4>

            <Carousel className='transform: translate3d(-100px, 0px, 0px); transition: all 0.05s ease 0s;'  style={{margintop:'2rem'}}  responsive={responsive} 
            autoPlay={true}
            infinite={true}
            // showDots={true}
            autoPlaySpeed={1000}
            transitionDuration={50}
            removeArrowOnDeviceType={["desktop","mobile","tablet","laptop"]} >

            <Card  className='c3t2  zoom' style={{ width: '95%' }}>
      <Card.Img variant="top" src={img9}/>
      <Card.Body>
        <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
      </Card.Body>
    </Card>
  
    <Card  className='c3t2  zoom' style={{ width: '95%' }}>
      <Card.Img variant="top" src={img10}/>
      <Card.Body>
        <Card.Title className="text-center"> Saraswathi Chakravarthi</Card.Title>
      </Card.Body>
    </Card>

    <Card  className='c3t2 zoom' style={{ width: '95%' }}>
      <Card.Img variant="top" src={img11}/>
      <Card.Body>
        <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
      </Card.Body>
    </Card>

    <Card  className='c3t2 zoom' style={{ width: '95%' }}>
      <Card.Img variant="top" src={img12}/>
      <Card.Body>
        <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
      </Card.Body>
    </Card>

    <Card  className='c3t2 zoom' style={{ width: '95%' }}>
      <Card.Img variant="top" src={img13}/>
      <Card.Body>
        <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
      </Card.Body>
    </Card>

    <Card  className='c3t2  zoom' style={{ width: '95%' }}>
      <Card.Img variant="top" src={img14}/>
      <Card.Body>
        <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
      </Card.Body>
    </Card>

</Carousel>

            </Col>
        </Row>
    </Container>
  )
}

export default Members;


// import React from 'react'
// import { Container, Row,Col } from 'react-bootstrap'
// import Carousel from 'react-multi-carousel';
// import 'react-multi-carousel/lib/styles.css';
// import Card from 'react-bootstrap/Card';
// import img9 from "../images/advsr1.png";
// import img10 from "../images/advsr2.png";
// import img11 from "../images/advsr3.png";
// import img12 from "../images/advsr4.png";
// import img13 from "../images/advsr5.png";
// import img14 from "../images/advsr6.png";

// function Members () {
//     const responsive = {
//         superLargeDesktop: {
//           // the naming can be any, depends on you.
//           breakpoint: { max: 4000, min: 3000 },
//           items: 6
//         },
//         desktop: {
//             breakpoint: { max: 3000, min: 1024 },
//             items: 5
//           },
//       };

//   return (



//     <Container style={{marginTop:'5rem'}}>
//         <Row >
//             <Col >
//            <h4  className='c3t1'>Advisory Members</h4>

//             <Carousel className='transform: translate3d(-100px, 0px, 0px); transition: all 0.05s ease 0s;'  style={{margintop:'2rem'}}  responsive={responsive} 
//             autoPlay={true}
//             infinite={true}
//             // showDots={true}
//             autoPlaySpeed={1000}
//             transitionDuration={50}
//             removeArrowOnDeviceType={["desktop","mobile","tablet","laptop"]} >

//             <Card  className='c3t2  zoom' style={{ width: '95%' }}>
//       <Card.Img variant="top" src={img9}/>
//       <Card.Body>
//         <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
//       </Card.Body>
//     </Card>
  
//     <Card  className='c3t2  zoom' style={{ width: '95%' }}>
//       <Card.Img variant="top" src={img10}/>
//       <Card.Body>
//         <Card.Title className="text-center"> Saraswathi Chakravarthi</Card.Title>
//       </Card.Body>
//     </Card>

//     <Card  className='c3t2 zoom' style={{ width: '95%' }}>
//       <Card.Img variant="top" src={img11}/>
//       <Card.Body>
//         <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
//       </Card.Body>
//     </Card>

//     <Card  className='c3t2 zoom' style={{ width: '95%' }}>
//       <Card.Img variant="top" src={img12}/>
//       <Card.Body>
//         <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
//       </Card.Body>
//     </Card>

//     <Card  className='c3t2 zoom' style={{ width: '95%' }}>
//       <Card.Img variant="top" src={img13}/>
//       <Card.Body>
//         <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
//       </Card.Body>
//     </Card>

//     <Card  className='c3t2  zoom' style={{ width: '95%' }}>
//       <Card.Img variant="top" src={img14}/>
//       <Card.Body>
//         <Card.Title className="text-center">Saraswathi Chakravarthi</Card.Title>
//       </Card.Body>
//     </Card>

// </Carousel>

//             </Col>
//         </Row>
//     </Container>
//   )
// }

// export default Members;
// import {useState,useEffect} from 'react'

// function Members() {
//   const [count, setCount] = React.useState(0);

//   return (
//     <div>
 

// useEffect(
//         () => {
//             const timer = () => {
//                 setCount(count + 1);
//             }

//             // if you want it to finish at some point
//             if (count >= 10) {
//                 return;
//             }
//             const id = setInterval(timer, 1000);
//             return () => clearInterval(id);
//         },
//         [count]
//     );
//     </div>
//   )
// }

// export default Members