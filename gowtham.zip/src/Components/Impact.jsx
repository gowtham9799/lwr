import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import Carousel from 'react-bootstrap/Carousel';
import img1 from "../images/121.jpg"
import img2 from "../images/122.jpg"
import img3 from "../images/123.jpg"
import img4 from "../images/124.jpg"

function Impact (props) {
  return (
    
    <Container id='Impact' target="blank" style={{marginTop:'8rem'}} className='ab2'>
         <Carousel   
            autoPlay={true}
            infinite={true}
            showDots={true}
            autoPlaySpeed={1000}
            transitionDuration={50}
            removeArrowOnDeviceType={["desktop","mobile","tablet","laptop"]}>
         <Carousel.Item >
            <div>
        <h3  style={{paddingTop:'0rem'}} className='c3t1'> impact</h3>
        <Row>
           
            <Col lg={6} >
          
                <img  style={{width:'95%',borderRadius:'15px'}} src={img1} className="zoom"></img>
          
            </Col>
            <Col lg={6} className="zoom">
           <Row style={{backgroundcolor:'black',borderRadius:'20px'}}>
              <h4 className='c3t1'> Early Detection</h4>
           </Row>
           <Row>
              <h6 style={{marginTop:'2rem' }}>It is proven that early detection and intervention between 18 to 48 months have the power to alter
                 an "At-Risk" child's development path and improve outcomes for the future.</h6>
           </Row>
           </Col>
          
        </Row>
        </div>
        </Carousel.Item>

        <Carousel.Item   >
        <div>
        <h3 className='c3t1'> impact</h3>
        <Row>
           
            <Col lg={6}>
           
                <img  style={{width:'98%',borderRadius:'20px'}} src={img2}></img>
            
            </Col>
            <Col lg={6}>
           <Row>
              <h4 className='c3t1'> Early Detection</h4>
           </Row>
           <Row>
              <h6 style={{marginTop:'2rem'}}>It is proven that early detection and intervention between 18 to 48 months have the power to alter
                 an "At-Risk" child's development path and improve outcomes for the future.</h6>
           </Row>
           </Col>
          
        </Row>
        </div>
        </Carousel.Item>

      

<Carousel.Item   >
   <div>
        <h3 className='c3t1 '> impact</h3>
        <Row>
           
            <Col lg={6} className='zoom'>
            
                <img  style={{width:'98%',borderRadius:'20px'}} src={img3}></img>
            
            </Col>
            <Col lg={6}>
           <Row>
              <h4 className='c3t1'> Early Detection</h4>
           </Row>
           <Row>
              <h6 style={{marginTop:'2rem',textAlign:'justify'}}>It is proven that early detection and intervention between 18 to 48 months have the power to alter
                 an "At-Risk" child's development path and improve outcomes for the future.</h6>
           </Row>
           </Col>
          
        </Row>
        </div>
        </Carousel.Item>

        <Carousel.Item   >
   <div>
        <h3 className='c3t1'> impact</h3>
        <Row>
           
            <Col lg={6}>
            
                <img  style={{width:'98%',borderRadius:'20px'}} src={img4}></img>
            
            </Col>
            <Col lg={6}>
           <Row>
              <h4 className='c3t1'> Early Detection</h4>
           </Row>
           <Row>
              <h6 style={{marginTop:'2rem',textAlign:'justify'}}>It is proven that early detection and intervention between 18 to 48 months have the power to alter
                 an "At-Risk" child's development path and improve outcomes for the future.</h6>
           </Row>
           </Col>
          
        </Row>
        </div>
        </Carousel.Item>

        </Carousel>
    </Container>
  )
}

export default Impact;


