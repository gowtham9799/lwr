import React from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import sol1 from "../images/Solutions.png";
import { BsSearch } from "react-icons/bs";
import { BsSpeedometer } from "react-icons/bs";
import { BsFillPersonCheckFill } from "react-icons/bs";
import { BsGraphUp } from "react-icons/bs";
import { BsFillPeopleFill } from "react-icons/bs";

function Solution (props) {
  return (
   <Container  id='Solution' target="blank">
    <Row>
    <h3 className='c3t1'>Solutions</h3>
        <Col lg={6}>
        <img
          className="d-block w-100 zoom  "
          src={sol1}
          style={{height:'450px',marginTop:'30px'}}
          alt="Second slide"
        />
        </Col>

        <Col lg={6} className='zoom'>
         <h4 className='c3t1 zoom'>Platform Benefits</h4>
        <div  style={{ display:'flex',marginTop:'45px'}}>
            
        
       
        </div>
       
        <Row  style={{ margin:'15px 0 0 0px'}}>
            <Col lg={2}>
            <BsSearch style={{ width:'30px',height:'30px',margin:'15px 0 0 25px'}}/>
            </Col>
            <Col lg={10}>
            <Row>
            <h4 className='c3t1'style={{textAlign:'justify'}}>  Improve detection accuracy</h4>
            </Row>
            <Row>
            <h6 style={{ paddingTop:'15px',textAlign:'justify'}}> Ready to use Artificial Intelligence model for detection</h6>
            </Row>
            </Col>
        </Row>

        <Row style={{ margin:'15px 0 0 0px'}}>
            <Col lg={2}>
            <BsSpeedometer style={{ width:'30px',height:'30px',margin:'15px 0 0 25px'}}/>
            </Col>
            <Col lg={10}>
            <Row>
            <h4 className='c3t1'style={{ textAlign:'justify'}}> Accelerate diagnosis</h4>
            </Row>
            <Row>
            <h6 style={{ paddingTop:'15px',textAlign:'justify'}}>Fast track detection and diagnosis</h6>
            </Row>
            </Col>
        </Row>

        <Row style={{ margin:'15px 0 0 0px'}}>
            <Col lg={2}>
            <BsFillPersonCheckFill style={{ width:'30px',height:'30px',margin:'15px 0 0 25px'}}/>
            </Col>
            <Col lg={10}>
            <Row>
            <h4 className='c3t1'style={{textAlign:'justify'}}> Consult with medical experts, therapists</h4> 
            </Row>
            <Row>
            <h6 style={{ paddingTop:'15px',textAlign:'justify'}}>Flexible consultation for expert opinion and follow-up</h6>
            </Row>
            </Col>
        </Row>

        <Row style={{ margin:'15px 0 0 0px'}}>
            <Col lg={2}>
            <BsGraphUp style={{ width:'30px',height:'30px',margin:'15px 0 0 25px'}}/>
            </Col>
            <Col lg={10}>
            <Row>
            <h4 className='c3t1'style={{textAlign:'justify'}}>Increase the likelihood of early intervention</h4> 
            </Row>
            <Row>
            <h6 style={{ paddingTop:'15px',textAlign:'justify'}}>Improve lives with proactive, and advanced treatment solutions</h6>
            </Row>
            </Col>
        </Row>

        <Row style={{ margin:'15px 0 0 0px'}}>
            <Col lg={2}>
            <BsFillPeopleFill style={{ width:'30px',height:'30px',margin:'15px 0 0 25px'}}/>
            </Col>
            <Col lg={10}>
            <Row>
            <h4 className='c3t1'style={{textAlign:'justify'}}>Connect with the parental community</h4> 
            </Row>
            <Row>
            <h6 style={{ paddingTop:'15px',textAlign:'justify'}}>Help and share thoughts with parents who are on similar journeys</h6>
            </Row>
            </Col>
        </Row>

        </Col>
    </Row>
   </Container>
  )
}
export default  Solution;