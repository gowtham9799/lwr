import firebase from "../src/components/firebase";

const db = firebase.ref("/chat");

class ChatDataService {

  getAll() {
    return db;
  }
  create(chat) {
    return db.push(chat);
  }
}

export default new ChatDataService();
