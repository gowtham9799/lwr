import React from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Container, Row, Col } from "react-bootstrap";
import { useState } from 'react';

function Task2() {
  
  const [email,setEmail]=useState('');
  const [value,setValue]=useState({
    email:''
  });
 
  function fun1(){
    const val={...value,email:email}
    setValue(val)
  }

  return (
    <Container>
      <Row>
        <Col  style={{ marginTop:'10rem' }} lg={6}>
        <Form>
    <Form.Group className="mb-3" controlId="formBasicEmail">
      <Form.Label>Email address</Form.Label>
      <Form.Control type="email" placeholder="Enter email"id='name1' onChange={(e)=>setEmail(e.target.value)} />
      <Form.Text className="text-muted">
        We'll never share your email with anyone else.
      </Form.Text>
    </Form.Group>

    <Form.Group className="mb-3" controlId="formBasicPassword">
      <Form.Label>Password</Form.Label>
      <Form.Control type="password" placeholder="Password" />
    </Form.Group>
    <Form.Group className="mb-3" controlId="formBasicCheckbox">
      <Form.Check type="checkbox" label="Check me out" />
    </Form.Group>
    <Button variant="primary" onClick={fun1}>
      Submit
    </Button>
  </Form>
        </Col>

        <Col   style={{ marginTop:'10rem' }} lg={6}>
        <p id='p1' onClick={"fun2()"}>{value?.email}</p>
        </Col>
      </Row>
    </Container>
  
  )
}

export default Task2