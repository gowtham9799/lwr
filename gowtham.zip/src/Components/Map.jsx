import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'


function Map () {
   
  return (
    <Container fluid>
        <Row>
            <Col>
            <div   className="mapouter">
              <div style={{ width:'100%'}} className="gmap_canvas"><iframe className="gmap_iframe" frameBorder={0} scrolling="no" marginHeight={0} marginWidth={0} src="https://maps.google.com/maps?width=600&height=400&hl=en&q=University of Oxford&t=&z=14&ie=UTF8&iwloc=B&output=embed" />
            <a href="https://piratebay-proxys.com/">Piratebay</a></div>
            <style dangerouslySetInnerHTML={{__html: ".mapouter{position:relative;text-align:right;width:100%;height:750px;}.gmap_canvas {overflow:hidden;background:none!important;width:100%px;height:750px;}.gmap_iframe {width:100%!important;height:750px!important;}" }} /></div>
            </Col>
        </Row>
    </Container>
  )
}

export default Map;