import React from 'react'
import { Button, Col, Container, Row } from 'react-bootstrap'
import pic7 from "../images/com.jpg"

function Community (props) {
  return (
    <Container id='Community' target="blank" className='zoom' style={{marginTop:'3rem'}}>
    <Row>
    <h3 style={{marginTop:'2rem'}} className='c3t1' >Community</h3>
        <Col lg={6}>
        <img
          className="d-block w-100 zoom"
          src={pic7}
          style={{height:'350px',borderRadius:'20px',marginTop:'10px'}}
          alt="Second slide"
        />
        </Col>


        <Col lg={6} >
         <h6 style={{ textAlign:'justify'}} className=''>One of the most important steps in our journey is the community we intend to build around like-minded people who are handling, affected, or interested in the Autism Spectrum Disorder arena. We are eager to listen to your stories, life experiences, and learnings, which will benefit community members in their journey.</h6>

 <h6   style={{marginTop:'15px', textAlign:'justify'}}> We want to build a secure platform for our community members to share, learn, unlearn, relearn and enrich ASD-related information. We are looking for volunteers to join us in our journey to create awareness of the benefits of early detection and intervention for Autism Spectrum Disorder</h6>
        <Button className='zoom'>Join us</Button>
        </Col>
    </Row>
   </Container>
  )
}

export default Community;