import React from 'react';
import { Row, Col, Container,Button } from "react-bootstrap";
import img60 from "../Components/../images/about2.jpg"

function About(props) {
  return (

    <Container id='About' className='zoom '  style={{marginTop:'20px',zIndex:'1000',width:'100%'}}>
        <Row className='ab2' style={{backgroundColor:'white'}} >
            <h3 style={{padding:'0px 0px 0px 0px' }}>About</h3>
            <Col lg={6} className='abou'>
            <img src={img60} style={{width:'100%',height:'400px',borderRadius:'20px',display:'inline-block'}}></img>
            </Col>
            <Col lg={6} >
            <div>
        <p style={{ textAlign:'justify'}}>Purple Butterfly is
          dedicated to meeting the need for early detection and intervention for children at
          risk of ASD in India using cutting-edge technology.</p>
        <p style={{ textAlign:'justify'}}>We are committed to creating an
          inclusive, reliable, sustainable, scalable digital ecosystem empowering parents,
          doctors, special educators, speech therapists, merchants, and anyone with service or
          business interest in the domain of ASD with a purpose to nurture and build a diverse
          but equitable community</p>
        <Button  style={{backgroundColor:'gray',width:'25%'}} className="zoom">Learn More</Button>
      </div>
            </Col>
        </Row>
    </Container>
  )
}

export default About;