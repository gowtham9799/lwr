import React from 'react'
import { Row, Col, Container } from "react-bootstrap";

function Grit() {
  return (
    <Container fluid>
  
   
      {/* <Col lg={4} className="box1">
      <Row className="box2">

      </Row>
      <Row className="box3" >
<Col className="box4">

</Col>
<Col className="box5">

</Col>
      </Row>
      </Col>


      <Col lg={8} className="box9">
      <Row>
      <Col className="box6">
      
      </Col>
      <Col className="box7">
      
      </Col>
      </Row>
      <Row>
      <Col lg={12} className="box8">
        
        </Col>
      </Row>
      <Row>
        <Col lg={4} className="box10">
        
        </Col>
        <Col lg={4} className="box11">
        
        </Col>
        <Col lg={4} className="box12">
        
        </Col>
      </Row>
      </Col> */}
<Row className="ro1" style={{height:'600px'}}>
<Col lg={4} sm={6} style={{height:'600px'}}>
<Row className='boxc1' style={{height:'200px',backgroundColor:'skyblue',fontSize:'150px'}}>1</Row>
<Row className='boxc4' style={{height:'400px',backgroundColor:'yellow',fontSize:'150px'}}>4</Row></Col>

<Col lg={4} sm={6} style={{height:'600px'}}>
<Row className='boxc2' style={{height:'200px',backgroundColor:'red',fontSize:'150px'}}>2</Row>
<Row style={{height:'200px'}}>
  <Col className='boxc5' style={{height:'200px',backgroundColor:'green',fontSize:'150px'}} lg={6}>5</Col>
  <Col className='boxc6' style={{height:'200px',backgroundColor:'skyblue',fontSize:'150px'}} lg={6}>6</Col></Row>
<Row className='boxc7' style={{height:'200px',backgroundColor:'black',fontSize:'150px'}}>7</Row></Col>

<Col lg={4} sm={6} style={{height:'600px'}}>
<Row className='boxc3' style={{height:'300px',backgroundColor:'pink',fontSize:'150px'}}>3</Row>
<Row><Col className='boxc8' style={{height:'300px',backgroundColor:'yellow',fontSize:'150px'}} lg={6}>8</Col>
<Col className='boxc9' style={{height:'300px',backgroundColor:'blue',fontSize:'150px'}} lg={6}>9</Col></Row></Col>

    </Row>
   </Container>
  );
}

export default Grit