import React from 'react'
import Header from "./Header";
import Component1 from "./Component1";
import About from "./About";
import Solution from "./Solution";
import Impact from "./Impact";
import Community from "./Community";
// import Component6 from "./Components/Component6";
import Members from "./Members";
import Cofounder from "./Cofounder";
import Contact from "./Contact";
import Map from "./Map";
import Footer from "./Footer";


export default function Home() {
  return (
    <div>

<Header/> 
       <Component1/>
    <About/>
    <Solution/>
     <Impact/>
    <Community/> 
    {/* <Component6/> */}
     <Members/>
     <Cofounder/>
    <Contact/>
    <Map/>
    <Footer/> 
    </div>
  )
}
