import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import sol2 from "../images/contact.png"
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

function Contact (props) {
  return (
    <Container id='Contact' target="blank" className='' style={{marginTop:'8rem'}}>
    <Row>
    <h3 className='c3t1'>Get In Touch</h3>
        <Col lg={6} >
        <img
          className="d-block w-100 zoom"
          src={sol2}
          style={{height:'500px'}}
          alt="Second slide"
        />
        </Col>

        <Col lg={6}>
        <Row  style={{ margin:'35px 0 0 0'}}>
            <Col lg={12}>
            <Form.Control type="email" placeholder="Enter Your Name" />
            </Col>
            
        </Row>

        <Row  style={{ margin:'35px 0 0 0px'}}>
            <Col lg={12}>
            <Form.Control type="email" placeholder="Enter Your email" />
            </Col>
            
        </Row>

        <Row  style={{ margin:'35px 0 0 0px'}}>
            <Col lg={12}>
            <Form.Control type="email" placeholder="Enter Your Phone Number" />
            </Col>
            
        </Row>
     
        <Row  style={{ margin:'35px 0 0 0px',}}>
            <Col lg={12}>
            <Form.Control style={{ height:'5rem'}} type="email" placeholder="Enter a Message" />
            </Col>
            
        </Row>

<Row>
    <Col>
    <Button style={{ margin:'25px 0 0 0px',marginLeft:'15px'}}>Sent Message</Button>
    </Col>
</Row>
      

        </Col>
    </Row>
   </Container>
  )
}

export default Contact ;