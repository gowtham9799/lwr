import React from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import img17 from "../images/Vijay.jpg";
import {  Row, Col, Container } from "react-bootstrap";
import {ImLinkedin } from 'react-icons/im';

function Cofounderchild(props) {
  console.log(props)

  return (
    <Modal
    {...props}
    show={true}
    size="lg"
    aria-labelledby="contained-modal-title-vcenter"
    centered
  >
    <Modal.Header closeButton  style={{ backgroundColor:'blueviolet' }}>
      <Modal.Title id="contained-modal-title-vcenter" style={{textalign:'center'}}>
      Subhrojyothi Mukherjee
      </Modal.Title>
    </Modal.Header>
    <Modal.Body>
        <Container>
        <Row>
            <Col lg={5}>
                <Row>
                    <div>
                    <img  style={{width:'99%',height:'350px'}} src={props.data.img}></img> 
                    </div>
               
                </Row>
                <Row >
<div style={{width:'92%',height:'50px',backgroundColor:'blueviolet',text:'center',marginLeft:'12px'}}>
<ImLinkedin  style={{width:'100%',height:'50px',Color:'white',paddingTop:'10px',backgroundcolor:"blueviolet"}}/>
</div>
                
                </Row>
            </Col>

            <Col  lg={7}>
            <h6  style={{textAlign:'justify'}}>Subhrojyoti is a seasoned business leader specializing in large business transformation, P&L management and growth acceleration. He has worked in diverse industries with organizations like TATA, Bharti Airtel, Vediocon group, Reliance group etc. Over the years Subhrojyoti has built an excellent credibility of near perfect diagnosis of business pain points and define, design and deliver sustainable solutions for the same. Subhrojyoti is an avid Rotarian and he has been spending considerable time working pro-bono on meaningful projects in the space of poverty alleviation and economic empowerment.</h6>
            </Col>
        </Row>
        </Container>
    </Modal.Body>
    <Modal.Footer>
      <Button onClick={props.onHide}>Close</Button>
    </Modal.Footer>
  </Modal>
  )
}

export default Cofounderchild;