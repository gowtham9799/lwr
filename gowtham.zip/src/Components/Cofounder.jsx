import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import Card from "react-bootstrap/Card";
import img15 from "../images/cofun1.jpg";
import img16 from "../images/cofun2.jpg";
import img17 from "../images/Vijay1.jpg";
import Modal from "react-bootstrap/Modal";
import Cofounderchild from "./Cofounderchild";

function Cofounder(props) {
  const [modalShow, setModalShow] = React.useState(false);
  const [img, setImage] = React.useState("");

  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 3,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3,
    },
  };
  function Dta(img) {
    setImage(img);
    setModalShow(true);
  }
  return (
    <Container style={{ marginTop: "5rem" }}>
      <Row>
        <h4 className="c3t1">Cofounder</h4>
        <Carousel
          style={{ margintop: "2rem" }}
          responsive={responsive}
          autoPlay={true}
          infinite={true}
          autoPlaySpeed={1000}
          transitionDuration={50}
          removeArrowOnDeviceType={["desktop", "mobile", "tablet", "laptop"]}
        >
          <Col lg={4}>
            <Card
              className="c3t2 text-center zoom"
              style={{ width: "25rem", Paddingright: "10px" }}
              onClick={() => Dta(img17)}
            >
              <Card.Img variant="top" src={img17} />
              <Card.Body>
                <Card.Title>Vijay Ramamoorthy</Card.Title>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={4}>
            <Card
              className="c3t2 text-center zoom"
              style={{ width: "25rem", Paddingright: "10px" }}
              onClick={() => Dta(img16)}
            >
              <Card.Img variant="top" src={img16} />
              <Card.Body>
                <Card.Title>Debangshu Dasgupta</Card.Title>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={4}>
            <Card
              className="c3t2 text-center zoom"
              style={{ width: "25rem", Paddingright: "10px" }}
              onClick={() => Dta(img15)}
            >
              <Card.Img variant="top" src={img15} />
              <Card.Body>
                <Card.Title>Subhrojyothi Mukherji</Card.Title>
              </Card.Body>
            </Card>
          </Col>

         
        </Carousel>
      </Row>
     {
      modalShow&&<Cofounderchild data={{img}} onHide={()=> setModalShow(false)}></Cofounderchild>
     }
     
    </Container>
  );
}

export default Cofounder;
