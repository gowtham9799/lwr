import Nav from 'react-bootstrap/Nav';
import {NavLink } from 'react-router-dom';
import Navbar from 'react-bootstrap/Navbar';
import logo from "../images/logo1.png"
import { Col, Container ,Row} from 'react-bootstrap';
function   Header(props) {

  return (
    <Container fluid target="blank">
      <Row>
        <Col className='' style={{width:'100%',padding:'0px'}} >

        <Navbar  bg="light" expand="lg"  style={{ position:"fixed",zIndex:'1',width:'100%'}} >
      
       
          <Col lg={2} >
          <Navbar.Brand href="#"> 
           <img src={logo} style={{marginLeft:'20px',width:'75%',height:'65px'}}
              className="d-inline-block align-top"
              alt="logo"
              
            />
            </Navbar.Brand>
          </Col>
      
        
        <Navbar.Toggle style={{justifyContent:'end',justifyItems:'end',padding:'0px'}} />
        
        <Col lg={10} style={{ }}>
        <Navbar.Collapse style={{float:'right',marginRight:'5px'}} >
       
          <Nav
            className="ho"
            style={{ maxHeight:'300px',textAlign:'right',paddingLeft:'20px'}}>
            <Nav.Link className='text-center zoom text-start' style={{color:'black' }} href="/" path='/' target="blank">HOME</Nav.Link>
            <Nav.Link className='zoom ' style={{color:'black' }} href="#About" path='/About' >ABOUT</Nav.Link>
            <Nav.Link className='zoom ' style={{color:'black' }} href="#Solution" path='/Solution' target="blank">SOLUTIONS</Nav.Link>
            <Nav.Link className='zoom ' style={{color:'black' }} href="#Impact" path='/Impact' target="blank">IMPACT</Nav.Link>
            <Nav.Link className='zoom ' style={{color:'black' }} href="#Community"  path='/Community' target="blank">COMMUNITY</Nav.Link>
            <Nav.Link to='/Blog' className='zoom '><NavLink to={"/Blog"}>BLOG</NavLink></Nav.Link>
            <Nav.Link className='zoom ' style={{color:'black' }} href="#Contact"  path='/Contact' target="blank">CONTACT</Nav.Link>
          </Nav>
        </Navbar.Collapse>
        </Col>
    </Navbar>

        </Col>
      </Row>
    </Container>
     
  )
}
export default Header;