import React from 'react';
import { Col, Container ,Row} from 'react-bootstrap';
import { FaInstagram } from "react-icons/fa";
import { AiFillLinkedin } from "react-icons/ai";
import { FaTwitter } from "react-icons/fa";
import { BsFacebook} from "react-icons/bs";
import {AiOutlineHome} from "react-icons/ai";
import {BsTelephoneOutbound} from "react-icons/bs";
import {AiOutlineMail} from "react-icons/ai";




function Footer () {
  return (
    <Container fluid style={{marginbottom:'20px'}}>
        <Row style={{backgroundColor:'#2d1046'}}>
<Col lg={2}></Col>
            <Col lg={6} >
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>HOME</h4></Row>
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>ABOUT</h4></Row>
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>SOLUTIONS</h4></Row>
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>IMPACT</h4></Row>
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>COMMUNITY</h4></Row>
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>BLOG</h4></Row>
            <Row><h4 style={{color:'white',paddingTop:'3rem'}}>CONTACT</h4></Row>
            <Row style={{color:'white',marginTop:'3rem' ,paddingbottom:'80px'}}>
                <Col lg={1}><FaInstagram style={{width:'35px',height:'35px'}}/></Col>
                <Col  lg={1}><AiFillLinkedin style={{width:'35px',height:'35px'}}/></Col>
                <Col  lg={1}><FaTwitter style={{width:'35px',height:'35px'}}/></Col>
                <Col  lg={1}><BsFacebook style={{width:'35px',height:'35px'}}/></Col> 
            </Row>
            </Col>



            
            <Col lg={4} style={{justifycontent:'center'}} >
            <Row>
                <Col lg={1}> <AiOutlineHome style={{width:'35px',height:'35px' , marginTop:'40px',color:'white'}}/></Col>
                <Col lg={11}>  <h4 style={{color:'white',marginTop:'3rem'}}>HOME</h4></Col>
               
            </Row>
            <Row><h4 style={{color:'white',marginTop:'20px'}}>Corporate Office</h4></Row>
            <Row><h5 style={{color:'white',marginTop:'20px', textAlign:'justify'}}>Rainmakers Workspace - Suit- 213, <br/>2nd Floor, Ramanashree Arcade, <br/> 18 M.G. Road, Bengaluru-560001</h5></Row>
            <Row><h4 style={{color:'white',marginTop:'20px'}}>Development Center</h4></Row>
            <Row><h5 style={{color:'white',marginTop:'20px', textAlign:'justify'}}>Workpod, 76-77, Nava India Rd,  <br/>KR Puram, Avarampalayam, <br/>Coimbatore, Tamil Nadu 641006.</h5></Row>
            <Row><h4 style={{color:'white',marginTop:'20px'}}>USA</h4></Row>
            <Row><h5 style={{color:'white',marginTop:'20px', textAlign:'justify'}}>1330 Avenue of the Americas,  <br/>Suite 23A, New York City, <br/> NY USA</h5></Row>
            <Row>
                <Col lg={1}> <BsTelephoneOutbound style={{width:'35px',height:'35px' , marginTop:'20px' ,color:'white'}}/></Col>
                <Col lg={11}>  <h5 style={{color:'white',marginTop:'20px'}}>+91 6380355874</h5></Col>
               
            </Row>
            <Row>
                <Col lg={1}> <AiOutlineMail style={{width:'35px',height:'35px' , marginTop:'28px',color:'white'}}/></Col>
                <Col lg={11}>  <h5 style={{color:'white',marginTop:'32px',marginbottom:"20px"}}>Mail us</h5></Col>
            </Row>
            </Col>
        </Row>


        <Row>
    <Col>
    <h5 style={{textAlign:'center',margin:'20px 0 20px 0'}}>Purple Butterfly Copyright ©2022 .</h5>
    </Col>
   </Row>

    </Container>
   
  )
}

export default Footer;