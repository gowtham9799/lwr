import React from "react";
import { useRef,useState,Form } from "react";

export default function Otp()
{
    const inputref = useRef(); 
    const [count,setCount] =useState('');
    const[val,setVal] = useState();

    
    const handesubmit = ()=>
    {
    const f1 = Math.random()*10000;
    const f11 = Math.ceil(f1);
    alert("Otp : "+f11); 
       setCount(f11);
    }  

    const submit=()=>
    {
    
        const alert1 = parseInt(count);
        const input = parseInt(inputref.current.value)

        if(input === alert1)
        {
            setVal("OTP is Correct");
        }
        else
        {
            setVal("OTP Is Wrong");
        }
    }  
    return(
        <div className="text-center">
            <Form>
<input type="number" name="mobile" placeholder="Mobile Number"></input>
            </Form>
        <button className="mt-5 btn btn-success" onClick={handesubmit}>OTP Generator</button><br/>
        <input type={"text"} placeholder="Enter the OTP" ref={inputref} className="mt-5"/><br/>
        <button className="btn btn-primary mt-5"onClick={submit}>Submit</button>
        <p>{val}</p>
        </div>
    );
}