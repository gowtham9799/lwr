import React, { Component } from 'react'
import img1 from "../images/Banner-1.jpg";
 import { TfiWrite } from "react-icons/tfi";
 import Navbar from 'react-bootstrap/Navbar';

function buildFileSelector(){
  const fileSelector = document.createElement('input');
  fileSelector.setAttribute('type', 'file');
  fileSelector.setAttribute('multiple', 'multiple');
  return fileSelector;
}

export default class Task3 extends Component {
  componentDidMount(){
    this.fileSelector = buildFileSelector();
  }
  
  handleFileSelect = (e) => {
    e.preventDefault();
    this.fileSelector.click();
  }
  render() {
    return (
      <div style={{position:'relative'}}>
        <img className='task3' style={{width:'100%',height:'700px',zIndex:'0'}} src={img1} ></img> 

       <TfiWrite onClick={this.handleFileSelect} style={{ width:'100px',height:'100px',bottom:0,right:0, position:'absolute',zIndex:'1000',color:'red'}}/>  
         
         
      </div>
    )
  }
}


