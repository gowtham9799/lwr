import React,{useState,useEffect} from 'react'
import { Container, Row,Col } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

function Dask() {
  const [data, setData] = useState();

  const fetchData = () => {
    fetch(`https://dummyjson.com/products`)
      .then((response) => response.json())
      .then((actualData) => {
      console.log(actualData.products);
      setData(actualData.products)
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
   <tbody>
        {data && data.map((value)=>
         <Card style={{ width: '18rem' }}>
         <Card.Body>
           <Card.Title>{value.title}</Card.Title>
           <Card.Text>{value.brand}</Card.Text>
           <Card.Text>{value.price}</Card.Text>
           <Card.Text>{value.rating}</Card.Text>
           <Button variant="primary">buy</Button>
         </Card.Body>
       </Card>
        )}
   
  
       
      </tbody>
  )
}

export default Dask