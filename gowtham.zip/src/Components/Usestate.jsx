// import React,{ useState } from 'react';


// function Usestate() {
//     const [count, setcount] = useState(4);
// const decrementcout = () => {
//     setcount(ps => ps - 1);
//     setcount(ps => ps - 1);
// }
// const incrementcout = () => {
//     setcount(ps => ps + 1);
//     setcount(ps => ps + 1);
// }




//   return (
//     <div>

// <button onClick={decrementcout}>-</button>
// <span>{count}</span>
// <button onClick={incrementcout}>+</button>
//     </div>
//   )
// }

// export default Usestate
// import React from 'react'

// const btn = document.querySelector('.btn');
// <button class="btn">Click Me</button>
// btn.addEventListener('click', () => {
//   let name = 'John doe';
//   console.log(name.toUpperCase())
// })
// function usestate() {
//   return (
//     <div>
  
//     </div>
//   )
// }

// export default usestate;