import React from 'react'
import { Col, Container, Row} from 'react-bootstrap';
import img32 from "../images/Group32.jpg";
import img33 from "../images/autistic33.jpg";
import img35 from "../images/valuable35.jpg";
function Blogin2() {
  return (
    <Container fluid>
    <Row>
        <Col>

<Row>
    <Col lg={12}>
    <img  className='w-100' src={img32} ></img>
    </Col>
</Row>
<Row>
    <Col lg={12}>
    <Row><h4 className='c3t1 text-center'>WHEN A KID IS ON THE SPECTRUM - OR JUST OFF IT</h4></Row>
    <Row><h6 className=' text-center' style={{padding:'30px 90px 0px 90px'}}>What do Albert Einstein, Bob Dylan, Sir Issac Newton, Henry Cavendish, and Daryl Hannah have in common? Apart from being famous personalities, they are all individuals who have dealt with autism spectrum disorder. But they did not allow living on the spectrum to affect their capabilities. Rather, they went ahead to excel in their fields and professions.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>Though ASD as a neurological condition has been prevalent for centuries, very often due to lack of awareness and empathy, news of a child being detected with it is met with a host of negative reactions among the family and friends.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>This is more than apparent in India, where the process by itself remains complicated and traumatic for parents and guardians, who are often the primary caregivers.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>After rounds of consultations, when detection is positively confirmed, they are left confused, bewildered, and upset. This usually tends to have a severe psychological impact on the child, who is at once dealing with a clinical condition and disturbed home environment. </h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>Clearly this is unwanted. Everyone in the family should be spared such emotional upheaval and distress when the news hits home.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}> So, the need of the hour is to wake up and smell the coffee.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>We need to remember that scores of persons with ASD have gone on to shine in their careers and passions. Scientific discovery or music, painting, or entertainment, these individuals have not only surpassed established thresholds but have created milestones that have left an indelible mark on generations to follow.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>When a child is detected with ASD, you as an adult need to first accept the facts. Accept that it is a form of a neurological disorder that needs special treatment and management. Accept that the child requires your empathy and support now more than ever to grow and emerge as an independent and confident individual. Accept that she requires your unquestionable love and patience.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>It is not the time to either live in denial, wallow in self-pity, or give in to half-baked ideas by non-specialists attempting to “cure” the child.</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>In our culture, there is no end to the guilt that parents undergo when their child is detected with ASD. It could start oftentimes, with the misplaced idea of being negligent and casual during the mother’s pregnancy or child’s early infancy, and finally, end with the notion of parents’ karma of another lifetime!</h6></Row>
    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>This attitude needs to be firmly nipped in the bud. If required, get professional help and/or counseling to come out of this self-deprecating situation.</h6></Row>
    <Row><h4 className='c3t1'  style={{padding:'30px 90px 0px 90px'}}>Souravi Sinha’s story</h4></Row>
    

<Container>
    <Row>
      <Col  lg={4}><img style={{padding:'30px 10px 20px 0px',height:'30rem',width:'100%'}} src={img33}></img></Col>
      <Col  lg={8}></Col>
      
      
    </Row>
</Container>

    <Row><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>Sir Antony Hopkins – The octogenarian was diagnosed very late in life with ASD. As late as 2014, he disclosed the fact in an interview with the media in 2017. He has admitted that it is probably Asperger’s that has made him a loner for the most part of his life. He dislikes parties and events with too many attendees. His unique ability to memorize lengthy sentences for his role and deconstruct characters, by his own admission, is also due to this clinical condition. </h6></Row>
    <Row><h6  style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}> Bob Dylan – An influential figure in popular music and culture for more than fifty years, Bob Dylan’s “odd” behaviour has been attributed to ASD. He is legendary as a musician, singer, songwriter, artist, and author. He has been called out on several occasions right from his childhood for his odd behaviour. The American pop star is believed to be mildly autistic.</h6></Row>
    <Row><h6  style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}>Daryl Hannah – In her own words, an American actress and popular icon of the 80s says that she “was a little odd and incredibly introverted and withdrawn” when she was young. It is now well known that she suffered from Asperger’s at the time, but due to a lack of awareness, she had to struggle for several years and was subjected to bullying in school. Today, Hannah is a confident individual and iconic star of popular films like Kill Bill, Splash, and Blade Runner. Having overcome her inhibitions, she leads a successful life befitting a star, other than that of an involved environmental activist. </h6></Row>
    <Row><h6  style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}> Satoshi Tajiri – Born in Tokyo, Satoshi Tajiri developed the habit of collecting bugs and arcade games as a young child. It has been observed that children with ASD usually start “collecting” objects from a young age. In Satoshi’s case, this habit soon turned into an obsession. It grew progressively stronger taking up so much time and attention that it led to him bunking classes and failing in high school. Interestingly, Satoshi went on to harness his obsession to create Pokemon, a game all about collections that became a worldwide phenomenon in recent times. As a high-functioning high-functioning current-day real-time autistic individual, Satoshi is a current-day example of how to manage life successfully despite being on the spectrum.</h6></Row>
    <Row><div><h6  style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}> Other than the ones mentioned, history is replete with examples of superlative individuals who have lived and achieved wonders despite being autistic:</h6>
    <ul>
      <li> <h6  style={{padding:'10px 10px 0px 90px',textDecoration:'none'}}>1.Leonardo da Vinci – Artist </h6></li>
      <li> <h6   style={{padding:'10px 10px 0px 90px'}}>2.Alfred Hitchcock – Film Director</h6></li>
      <li> <h6  style={{padding:'10px 10px 0px 90px'}}>3.Thomas Alva Edison – Inventor</h6></li>
      <li><h6  style={{padding:'10px 10px 0px 90px'}}>4.Alexander Graham Bell – Inventor</h6></li>
      <li> <h6  style={{padding:'10px 10px 0px 90px'}}>5.Benjamin Franklin – Inventor</h6></li>
      <li> <h6  style={{padding:'10px 10px 0px 90px'}}>6.Henry Ford – Inventor</h6></li>
      <li> <h6  style={{padding:'10px 10px 0px 90px'}}>7.Ludwig van Beethoven – Musician</h6></li>
      <li> <h6  style={{padding:'10px 10px 0px 90px'}}>8.George Orwell – Writer</h6></li>
      <li> <h6  style={{padding:'10px 10px 0px 90px'}}>9.Jane Austen – Writer</h6></li>
      <li> <h5  style={{padding:'10px 90px 0px 90px',color:'black',textAlign:'justify'}}>Keep a watch on this section for more real-time inspiration from India. Read interesting stories and gain insights on how Indian parents deal with ASD in their kids and help them triumph over odds.</h5></li>
     
    </ul>
    </div></Row>

    <Row><h4 className='c3t1'  style={{padding:'30px 90px 0px 90px'}}>Souravi Sinha’s story</h4></Row>
    

    <Container>
        <Row>
          <Col  lg={4}><img style={{padding:'30px 10px 20px 0px',height:'30rem',width:'100%'}} src={img35}></img></Col>
          <Col  lg={8}></Col>
          
          
        </Row>
    </Container>
    
    <Row><div>
      <h4 className='c3t1'  style={{padding:'30px 90px 0px 120px'}}> References:</h4>
      <ul>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>People with autism spectrum disorder ASD</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>History's 30 most inspiring people on the autism spectrum</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>7 famous people with autism spectrum disorder</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>News about Autism</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>Anthony hopkins and his estranged daughter's abandonment addictions and his aspergers syndrome</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>Bob dylan is mildly autistic</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>Einstein and newton showed signs of autism</a></li>
        <li><a style={{padding:'30px 90px 0px 90px',textAlign:'justify'}} href=''>Henry Cavendish and Asperger's syndrome A new understanding of the scientist</a></li>
        <li><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}><span><h4>Tags:</h4></span> Autism, Autism Spectrum Disorders, Health, Celebrities with ASD, Inspiration</h6></li>
        <li><h6 style={{padding:'30px 90px 0px 90px',textAlign:'justify'}}><span><h4>DISCLAIMER: </h4></span> While every effort has been made to obtain information from reliable and authentic sources, this is not a substitute for medical advice. You should seek the guidance of a doctor or a qualified medical professional in case of need.</h6></li>
      </ul>
      
      </div></Row>
    <Row><h6> </h6></Row>


    </Col>
</Row>

        </Col>
    </Row>
   </Container>
  )
}

export default Blogin2;