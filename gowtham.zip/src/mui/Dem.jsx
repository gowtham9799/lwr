import React from 'react'
import { useState } from "react";
import ReactDOM from "react-dom/client";


function Dem() {
     const [color, setColor] = useState("red");
  return (
    <div>
        <h1>My favorite color is {color}!</h1>
      <button
        type="button"
        onClick={() => setColor("blue")}
      >Blue</button>
    </div>
  )
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Dem />);
export default Dem