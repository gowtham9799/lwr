import "bootstrap/dist/css/bootstrap.min.css";
import {BrowserRouter,Routes, Route} from "react-router-dom";
import "./App.css";
// import Grit from "../src/Components/Grit";
import Home from "./Components/Home";

import Blog from "./Components/Blog";
import Blogin1 from "./Components/Blogin1";
import Blogin2 from "./Components/Blogin2";
// import MusicPlayerSlider from "./Components/MusicPlayerSlider";
// import TemporaryDrawer from "./mui/TemporaryDrawer";
// import Usestate from "./Components/Usestate";
// import Otp from "./Components/Otp";
// import Firebase from "./Components/Firebase";
// import Dem from "./mui/Dem";
import Card from "./mui/Card";
import Task from "./Components/Task";


function App() {
  return (
    <BrowserRouter>

  <div>
     {/* <Grit/>  */}
     <Task/>
    
    <Routes> 
                  {/* <Route path="/" element={<Home/>}></Route> */}
        {/* <Route path="/Blog" element={<Blog/>}/>
        <Route path="/blog1" element={<Blogin1/>}/>
        <Route path="/blog2" element={<Blogin2/>}/> */}
    </Routes> 
     


{/* <Task2/>  */}
     {/* <Task3/> */}
{/* <Usestate/> */}
{/* <Otp/> */}
{/* <Firebase/> */}
{/* <MusicPlayerSlider/>
<TemporaryDrawer/> */}
{/* <Dem/> */}

  </div>
  {/* <Card/> */}
  </BrowserRouter> 

  );
}

export default App;
